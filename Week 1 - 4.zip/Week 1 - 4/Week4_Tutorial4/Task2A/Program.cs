﻿using System;
using System.Threading;

namespace CNA_TUTORIAL4
{
    //Currently working threw it - use this resource to conintue https://docs.microsoft.com/en-us/dotnet/api/system.threading.semaphore?view=netcore-3.1
    class Program
    {
        //Simulates a limited resource pool , used to control threads
        private static Semaphore _pool;


        public int Shared_Data = 5;


        public class RaceCondition
        {
            static void Main(string[] args)
            {


                for (int i = 0; i <= 1; i++)
                {

                    Thread worker = new Thread(new ParameterizedThreadStart(Calculation));
                    worker.Start(i);

                }
                Thread.Sleep(500);
            }

            static public void Calculation(object num)
            {
                Program prog = new Program();
                int l_number = prog.Shared_Data;
                l_number += 1;
                Console.WriteLine(l_number);



            }

        }
    }

}

