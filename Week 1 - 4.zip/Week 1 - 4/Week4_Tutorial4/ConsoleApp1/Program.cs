﻿using System;
using System.Threading;

namespace CNA_TUTORIAL4
{

    public class Program
    {

        public static int Shared_Int = 5;
        private static Semaphore _pool;
        static void Main(string[] args)
        {

            _pool = new Semaphore(1, 2);
            for (int i = 1; i <= 2; i++)
            {
                Thread worker = new Thread(new ParameterizedThreadStart(Calculation));
                worker.Start(i);
            }
            Thread.Sleep(500);



        }
        public static void Calculation(object num)
        {
            _pool.WaitOne(100);


            Console.WriteLine("Thread {0} begins and waits for the semaphore.", num);
            Program.Shared_Int++;
            Console.WriteLine("Thread value : " + " " + Program.Shared_Int);
            Console.WriteLine("Current Thread released ", _pool.Release());
        }

    }

}

