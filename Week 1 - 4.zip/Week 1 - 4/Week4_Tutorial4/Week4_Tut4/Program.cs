﻿using System;
using System.Threading;

namespace CNA_TUTORIAL4
{
    class Program
    {
        //this keyword - Seen Frequently throughout.
        //Used to the class instance of o equal the parameter
        //You can use "." to access the isntance of a class member too

        //Buffer class holds reference to our data, used by production and consumer class
        public class Buffer
        {
            //Initalise Data
            private int Data;
            private bool Empty = true;

            public void Read(ref int data)
            {
                //Lock keyword ensures that one thread executes a peice of code at a time.
                //Ensuring that during the execution path of thread , when ecountering this code with lock method.
                //It ensures that one thread does not enter a critical section of code while another thread is in that critical section.

                lock (this)
                {

                    //Check whether the buffer is empty
                    if (Empty)

                        Monitor.Wait(this);
                    Empty = true;
                    data = this.Data;
                    Console.WriteLine("     " + data + " read");
                    Monitor.Pulse(this);

                }
            }

            public void Write(int data)
            {
                lock (this)
                {
                    //Check whether the buffer is full
                    if (!Empty)

                        Monitor.Wait(this);
                    Empty = false;
                    this.Data = data;
                    Console.WriteLine(data + " write");
                    Monitor.Pulse(this);

                }
            }
        }
        public class Producer
        {
            private Buffer buffer;
            private Random random = new Random();

            public Producer(Buffer buffer)
            {
                this.buffer = buffer;
            }
            public void Production()
            {
                for (int i = 1; i <= 10; i++)
                {
                    //Delay up to 500 milliseconds.
                    Thread.Sleep(random.Next(501));
                    //Call buffer class write method , iterates using "i" 10 times passing in new value , the role of the producer
                    buffer.Write(i);
                }
            }
        }
        public class Consumer
        {
            private Buffer buffer;
            private Random random = new Random();


            public Consumer(Buffer buffer)
            {
                this.buffer = buffer;
            }
            public void Consumption()
            {
                int data = -1;
                //Deducts data from shared resource , producer 
                for (int i = 1; i <= 10; i++)
                {
                    //Delay up to 500 milliseconds
                    Thread.Sleep(random.Next(501));
                    buffer.Read(ref data);
                    //Removes value added
                    data = -1;
                }




            }





        }
        public class PCDemo
        {
            static void Main(string[] args)
            {
                Buffer buff = new Buffer();
                Producer prod = new Producer(buff);
                Consumer con = new Consumer(buff);

                Thread ProducerThread = new Thread(new ThreadStart(prod.Production));
                Thread ConsumerThread = new Thread(new ThreadStart(con.Consumption));
                ProducerThread.Start();
                ConsumerThread.Start();





            }
        }
    }
}

