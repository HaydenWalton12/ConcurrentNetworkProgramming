﻿using System;
using System.Threading;

namespace CNA_TUTORIAL4
{
    public class Bowl
    {

        private int Food = 10;
        Random rand = new Random();
        Semaphore Forks;

        public Bowl(Semaphore Semy)
        {
            this.Forks = Semy;
        }

        public void Think()
        {
            Thread.Sleep(rand.Next(501));
        }
        public void Eat(object count)
        {

            while (Food > 0)
            {

                if (Food > 0)
                {

                    Forks.WaitOne();
                    Console.WriteLine("Philosopher {0} Takes the Forks.", count);
                    Food--;
                    Console.WriteLine("Philsopher {0} Eats", count);
                    Console.WriteLine("Philsopher {0} release the Forks.", count);
                    Forks.Release();
                }
                Think();
            }
        }
    }

    public class Demo
    {
        public static Semaphore Sem;

        static void Main()
        {

            Sem = new Semaphore(0, 2);
            Bowl Spag = new Bowl(Sem);
            for (int i = 1; i <= 5; i++)
            {

                Thread Philosopher = new Thread(new ParameterizedThreadStart(Spag.Eat));
                Philosopher.Start(i);
                Console.WriteLine("Philospher {0} sits down.", i);


            }
            Thread.Sleep(500);
            Sem.Release(2);
        }
    }


}

