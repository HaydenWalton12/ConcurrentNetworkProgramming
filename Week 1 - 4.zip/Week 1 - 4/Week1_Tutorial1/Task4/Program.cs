﻿using System;


namespace Con_Current_Network_Programming
{
    class Program
    {
        static void Main(string[] args)

        {
            int[] numbers = new int[10];

            Console.WriteLine("Enter 10 integers >>");

            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
                Console.WriteLine("\n ");


            }

            Array.Reverse(numbers);
            Console.WriteLine("\nReversed Input >> \n ");

            for (int i = 0; i < numbers.Length; i++)
            {

                Console.WriteLine(numbers[i]);
            }


        }
    }
}

