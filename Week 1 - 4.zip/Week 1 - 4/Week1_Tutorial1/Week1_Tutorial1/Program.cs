﻿using System;

namespace Con_Current_Network_Programming
{
    class Program
    {
        static void Main(string[] args)

        {
            //Console Class System - Can perform console based tasked 
            //WriteLine , Console function that performs as mentioned
            Console.WriteLine("Hello World!");
        }
    }
}

