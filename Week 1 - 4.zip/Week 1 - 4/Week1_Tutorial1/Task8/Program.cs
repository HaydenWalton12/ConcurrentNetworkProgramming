﻿using System;
using System.Collections.Generic;

namespace Con_Current_Network_Programming
{
    public class Animal
    {
        public virtual void Speak()
        {
            Console.WriteLine("Generic Animal Sound");

        }



    }
    public class Rat : Animal
    {

        public override void Speak()
        {
            Console.WriteLine("I am a rat ,squeak >:)");

        }

    }

    public class Dog : Animal
    {

        public override void Speak()
        {
            Console.WriteLine("I am a dog , woof :(");

        }

    }

    public class Cat : Animal
    {

        public override void Speak()
        {
            Console.WriteLine("I am a cat , MEOW!!");

        }

    }
    public class Horse : Animal
    {

        public override void Speak()
        {
            Console.WriteLine("I am a horse , NAYYYYYYYYYYYYYYYYYYYYYYYY ┌(0_0)┘");

        }

    }
    class Program
    {



        static void Main(string[] args)

        {
            Rat rat = new Rat();
            Dog dog = new Dog();
            Cat cat = new Cat();
            Horse horse = new Horse();
            int choice = 0;
        start:
            Console.WriteLine("Animal Menu \n 1.)Rat  2.)Dog  3.)Cat  4.)Horse  5.)Quit   \n Enter choice 1 - 5");
            choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {

                case 1:
                    rat.Speak();
                    goto start;
                    break;
                case 2:
                    dog.Speak();
                    goto start;
                    break;
                case 3:
                    cat.Speak();
                    goto start;
                    break;
                case 4:
                    horse.Speak();
                    goto start;
                    break;
                case 5:
                    Console.WriteLine("Goodbye!");
                    break;
                default:
                    break;

            };



        }



    }

}


