﻿using System;

namespace Con_Current_Network_Programming
{

    class Program
    {

        static void Main(string[] args)

        {


            int num1, num2;
            Console.WriteLine("Enter two values >> ");

            num1 = Convert.ToInt32(Console.ReadLine());
            num2 = Convert.ToInt32(Console.ReadLine());

            Add_Method(num1, num2);
        }


        //When creating functions in c# , since we create our programs in namespaces and inside are classes, you must add a access modifer to determine scope in program ,add static if you wish to further stretch the length of the function till end of execution.
        private static void Add_Method(int num1, int num2)
        {
            int num_1 = 0, num_2 = 0, total;


            num_2 = num2;
            num_1 = num1;
            total = num_1 + num_2;

            Console.WriteLine("Total Value is >>");
            Console.WriteLine(total);
        }
    }
}


