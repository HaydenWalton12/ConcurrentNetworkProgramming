﻿using System;

namespace Con_Current_Network_Programming
{
    class Program
    {
        static void Main(string[] args)

        {
            int num, num2, num_total = 0;

            Console.WriteLine("Enter 10 integer values >> \n");
            Convert.ToInt32(num_total);
            // intialize , condition determines iteration ,  increment 
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("Enter " + i + " number >> ");
                num = Convert.ToInt32(Console.ReadLine());


                //Will determine total value of numbers
                num_total = num_total + num;

            }
            //Outputs total
            Console.WriteLine("Total Value of 10 inputted Variables >> ");
            Console.WriteLine(num_total);

        }
    }
}

