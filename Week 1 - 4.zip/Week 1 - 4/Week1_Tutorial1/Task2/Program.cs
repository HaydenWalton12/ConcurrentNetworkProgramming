﻿using System;

namespace Con_Current_Network_Programming
{
    class Program
    {
        static void Main(string[] args)

        {
            //Local Variables Initialized
            int area, perimetre, height, width, num = 2;

            //Declare Inputs Needed
            Console.WriteLine("Enter height and width >> \n ");

            Console.WriteLine("Height >>");

            //We convert specifically to ToInt32 , signs variable to 32-bit signed interger , we need to do this since console specifically reads and processes string values.
            height = Convert.ToInt32(Console.ReadLine());



            Console.WriteLine("\nWidth >>");
            width = Convert.ToInt32(Console.ReadLine());

            //Forumla Multiplication that give us our values
            area = width * height;
            perimetre = num * width + num * height;

            //Output Perimeter and Area
            Console.WriteLine("\nThe value of said area is the following >> \n"); Console.WriteLine(area);
            Console.WriteLine("\nThe value of said perimetre is the following >>\n"); Console.WriteLine(perimetre);



        }
    }
}

