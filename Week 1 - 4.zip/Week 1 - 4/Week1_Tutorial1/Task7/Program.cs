﻿using System;

namespace Con_Current_Network_Programming
{

    class Program
    {

        static void Main(string[] args)

        {

            Random rand = new Random();
            int rand_int = rand.Next(0, 100);
            int guess;
            bool playing = true;
            Console.WriteLine("Enter in a value 0 - 100 >> ");
            while (playing == true)
            {


                guess = Convert.ToInt32(Console.ReadLine());
                if (guess > rand_int)
                {
                    Console.WriteLine("You was too high!");

                }
                else if (guess < rand_int)
                {

                    Console.WriteLine("You was too low!");

                }

                else if (guess == rand_int)
                {

                    Console.WriteLine("You win!", rand_int + " was the correct number.");
                    playing = false;

                }
            }
        }
    }
}
