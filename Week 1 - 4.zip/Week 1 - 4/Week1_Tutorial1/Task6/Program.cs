﻿using System;

namespace Con_Current_Network_Programming
{
    public class Member_Overloading
    {


        public int Add_Method(int num1, int num2)
        {
            return num1 + num2;
        }
        public float Add_Method(float num1, float num2)
        {
            return num1 + num2;
        }

    }
    class Program
    {

        static void Main(string[] args)

        {
            Member_Overloading calculation = new Member_Overloading();


            Console.WriteLine("Enter two values >> ");
            //Member OVerloading is simple , while two methods could share the same naming convention, 
            //One over the other is determined by the values entered into the calling of the function, as seen below , we can see 
            //both methods have the same name , however based upon changing one methods to type to a float, when we call and pass float values, it knows which one to call upon.
            Console.WriteLine(calculation.Add_Method(20, 12));
            Console.WriteLine(calculation.Add_Method(20.2f, 12.43f));

        }




    }

}
