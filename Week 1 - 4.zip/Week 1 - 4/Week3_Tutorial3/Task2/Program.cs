﻿using System;
using System.Threading;

namespace FiboancciApplication
{
    //Logic of Fiboancci Logic - The next number in sequence is the sum of its two preceeding numbers (both numbers before the next one) F(n)= F(n-1) +F(n-2)
    public class ThreadingExercise
    {
        static void Main(string[] args)
        {
            Console.Write("Length of the Fibonacci Series: ");
            int length = 10;
            int length2 = 20;
            int length3 = 30;
            Console.WriteLine("\nSequence 1 >> ");
            for (int i = 0; i < length; i++)
            {
                Thread thread1 = new Thread(new ThreadStart(() => FiboancciSequence.FiboancciLogic(i)));
                thread1.Start();
                Console.Write("{0} ", FiboancciSequence.FiboancciLogic(i));
            }
            Console.WriteLine("\nSequence 2 >> ");
            for (int i = 10; i < length2; i++)
            {
                Thread thread2 = new Thread(new ThreadStart(() => FiboancciSequence.FiboancciLogic(i)));
                thread2.Start();
                Console.Write("{0} ", FiboancciSequence.FiboancciLogic(i));
            }
            Console.WriteLine("\nSequence 3 >> ");
            for (int i = 20; i < length3; i++)
            {
                Thread thread3 = new Thread(new ThreadStart(() => FiboancciSequence.FiboancciLogic(i)));
                thread3.Start();
                Console.Write("{0} ", FiboancciSequence.FiboancciLogic(i));
            }



        }
    }

    public class FiboancciSequence
    {

        public static int FiboancciLogic(int number)
        {
            int n1 = 0, n2 = 1, total = 0;
            //Both conditions used to return the value 
            //We call "number" , our iterated value to give us the first two initial values, skipping for loop and returning value to output.
            if (number == n1) { return n1; }
            if (number == n2) { return n2; }


            //The int starts at 2 since we want to start iteration after the first two initial values , " 0 , 1"
            //The intial values will be 0 , 1 , upon this we iterate from 2 - to passed "number" value (being passed iterate value that executes function 10 times)
            //From the iteration , it will calculate using the formula below , to give us the next "num-ber" in the Fibonac-ci Sequence 


            for (int i = 2; i <= number; i++)  // main processing starts from here
            {
                total = n1 + n2;
                n1 = n2;
                n2 = total;
            }
            return total;
        }
    }


}



