﻿using System;
using System.Threading;

namespace SolvedApplication
{
    public class ThreadingExercise
    {

       
        static void Main(string[] args)
        {
            //Intialise Int Arrays
            int[] Numbers1 = new int[10];
            int[] Numbers2 = new int[10];
            int[] Numbers3 = new int[10];

            //Generate the random values to be sorted
            SortArray.Generate(Numbers1);
            SortArray.Generate(Numbers2);
            SortArray.Generate(Numbers3);

            //Output Intial unsorted list values
            Console.WriteLine("Inital Lists Are >> ");
            Console.WriteLine();
            SortArray.ToScreen(Numbers1);
            SortArray.ToScreen(Numbers2);
            SortArray.ToScreen(Numbers3);


            Thread thread1 = new Thread(new ThreadStart(() => ThreadingExercise.Sort(Numbers1 , 1)));
            Thread thread2 = new Thread(new ThreadStart(() => ThreadingExercise.Sort(Numbers2 , 2)));
            Thread thread3 = new Thread(new ThreadStart(() => ThreadingExercise.Sort(Numbers3 ,3)));

            thread1.Start();
            thread1.Join();
            thread2.Start();
            thread2.Join();
            thread3.Start();
            thread3.Join();


            Console.WriteLine("Sorted Lists Are >> ");
            Console.WriteLine();
            SortArray.ToScreen(Numbers1);
            SortArray.ToScreen(Numbers2);
            SortArray.ToScreen(Numbers3);

        }
        public static void Sort(int[] SortNumbers, int count)
        {
            int temporary;

            for (int i = 0; i < 10 - 1; i++)
            {
                for (int j = i + 1; j < 10; j++)
                {
                    if (SortNumbers[i] > SortNumbers[j])
                    {
                        temporary = SortNumbers[i];
                        SortNumbers[i] = SortNumbers[j];
                        SortNumbers[j] = temporary;


                    }
                }
                Console.WriteLine("Sorted" + count);


            }


        }







    }

    public class SortArray
    {
        public static void Generate(int[] NewNumbers)
        {

            //Create new instance of a class object , can reference members of class object via the use of the "new" keyword
            System.Random random = new System.Random();

            //Generates new number for each of the 10 elements iterated via loop into array , ele-ment value is an int from 0 - 50 
            for (int i = 0; i < 10; i++)
            {
                NewNumbers[i] = random.Next(50);
            }
        }

        public static void ToScreen(int[] NumbersToPrint)
        {
            for (int i = 0; i < 10; i++)
            {
                Console.Write(NumbersToPrint[i] + " " );
            }
            Console.WriteLine();
        }


    }
}
