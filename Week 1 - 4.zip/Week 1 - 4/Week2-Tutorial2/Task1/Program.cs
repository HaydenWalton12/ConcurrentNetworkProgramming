﻿using System;

//Library allowed for concurrency programming
using System.Threading;
namespace Threading


{
    public class ThreadClass
    {

        //Members
        private string text;
        int num;
        private int delay;
        public ThreadClass(string text, int delay)
        {
            //Uses to qualify the private members using local parameters
            //So when this is called, parameters passed , the private members will be in reference.

            //"this" used to diffrentiate between class members and method parameters if using the same name

            //private member = local member of same name
            this.delay = delay; this.text = text;

        }


        public void ThreadIncrement()
        {
            // Initlized , condition (determines iteration) , Increment (allows for iteration)
            for (int i = 1; i <= 100; i++)
            {
                //Sleep will pause execution of thread for set amount of time
                delay--;
                Thread.Sleep(1);
                Console.WriteLine(text + " " + delay);


            }


        }
        public void ThreadDecrement()
        {

            for (int i = 1; i <= 100; i++)
            {
                //Sleep will pause execution of thread for set amount of time
                delay++;
                Thread.Sleep(1);
                Console.WriteLine(text + " " + delay);


            }


        }


    }
    public class ThreadApplication
    {

        public static void Main()
        {

            ThreadClass t_O1 = new ThreadClass("A >>", 100);
            ThreadClass t_O2 = new ThreadClass("B >>", 0);

            //ThreadStart , method that executes on thread. 
            Thread thread1 = new Thread(new ThreadStart(t_O1.ThreadIncrement));//Delegate 1 (mentioned in previous branch "master")
            Thread thread2 = new Thread(new ThreadStart(t_O2.ThreadDecrement));

            thread1.Start();
            thread1.Join();
            thread2.Start();
        }
    }
}



