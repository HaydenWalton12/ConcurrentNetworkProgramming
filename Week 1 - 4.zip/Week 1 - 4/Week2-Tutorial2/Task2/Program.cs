﻿using System;

//Library allowed for concurrency programming
using System.Threading;
namespace Threading


{
    public class ThreadClass
    {

        //Members
        private int num;

        public ThreadClass(int num)
        {

            this.num = num;

        }



        public void ThreadInterval()
        {
            // Initlized , condition (determines iteration) , Increment (allows for iteration)
            for (int i = 1; i <= 100; i++)
            {
                float t_num = (float)num * 0.5f;
                t_num = t_num * 1000;

                Thread.Sleep((int)t_num);

                Console.WriteLine(num);


            }


        }

    }

    public class ThreadApplication
    {
        static int num1 = 0;
        static Thread[] Array_OF_Threads = new Thread[5];
        static ThreadClass[] Array_Of_ThreadClass = new ThreadClass[5];

        public static void Main()
        {

            ThreadClass t_O1;

            for (int i = 0; i < 5; i++)
            {

                t_O1 = new ThreadClass(num1);
                num1++;
                Array_Of_ThreadClass[i] = t_O1;



            }


            for (int i = 0; i < 5; i++)
            {

                Array_OF_Threads[i] = new Thread(new ThreadStart(Array_Of_ThreadClass[i].ThreadInterval));

            }

            for (int i = 0; i < 5; i++)
            {

                Array_OF_Threads[i].Start();



            }
        }
    }
}

