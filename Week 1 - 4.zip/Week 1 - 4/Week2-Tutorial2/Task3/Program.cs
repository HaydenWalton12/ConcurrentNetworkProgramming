﻿using System;

//Library allowed for concurrency programming
using System.Threading;
namespace Threading
{

    public class ThreadApplication
    {


        static int threadcount = 0;
        static bool flag = false;

        public static void Main()
        {
            Thread main_thread = new Thread(new ThreadStart(ThreadMain));
            main_thread.Start();

        }
        static public void ThreadMain()
        {
            int num = 0;
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Thread Main >> " + " " + num);

                num++;




            }
            Thread thread1 = new Thread(new ThreadStart(ThreadOne));
            Thread thread2 = new Thread(new ThreadStart(ThreadTwo));
            thread1.Start();
            thread2.Start();
            thread2.Join();
            threadcount++;
        }

        static public void ThreadOne()
        {
            int num = 9;
            for (int i = 0; i < 11; i++)
            {
                Console.WriteLine("Thread One >> " + " " + num);

                num++;


            }
            Thread thread3 = new Thread(new ThreadStart(ThreadThree));

            thread3.Start();
            thread3.Join();

            threadcount++;
        }

        static public void ThreadTwo()
        {
            int num = 9;
            for (int i = 0; i < 11; i++)
            {
                Console.WriteLine("Thread Two >> " + " " + num);

                num++;
            }
            threadcount++;
            Thread thread4 = new Thread(new ThreadStart(ThreadFour));

            thread4.Start();
        }
        static public void ThreadThree()
        {
            int num = 19;
            for (int i = 0; i < 11; i++)
            {
                Console.WriteLine("Thread Three >> " + " " + num);
                num++;

            }
            threadcount++;
            flag = true;
        }
        static public void ThreadFour()
        {
            int num = 19;
            for (int i = 0; i < 11; i++)
            {
                Console.WriteLine("Thread Four >> " + " " + num);

                num++;

            }
            threadcount++;
            flag = true;
            CheckCount();

        }

        static public void CheckCount()
        {
            if (flag == true)
            {
                Console.WriteLine("Threads in total was >> " + " " + threadcount);
            }
        }
    }

}

