﻿using System;
using System.Net.Sockets;
using System.Net;
using System.Collections.Concurrent;
using System.Threading;
using Packets;
using System.Collections.Generic;
using System.Linq;

namespace ServerProj_
{
 
    class Server
    {
        //Used to listen for connections from TCP Network Clients
        public TcpListener TCP_Listener;

        /// <summary>
        /// ConcurrentDictionary - Represents thread-safe collection (thread safe - Manipulates shared data so all threads behave as intended , eliminating incosistent results)
        /// Stores key/value pairs, this is designed so that we can have mulitple threads , safely accessing shared resources . Mitigates the need to lock a function during execution 
        /// We add a key and value to dictionary , executing thread , safely.
        /// Essentially - we use this to store our connected clients, giving a "key" as its element index.
        /// </summary>
        private ConcurrentDictionary<int, ConnectedClient> Clients;
       
        //Connectedclient class , acts as the servers acting class to send/recieve data from a client
        public ConnectedClient Connected_Client;

        //Passed as key , increments as each new client is made, to store other client on new thread safe on ConcurrentDictionary
        public int ClientKeyIndex = 0;

        public List<int> Game_ID_List = new List<int>();
        //Stores Clients client list
        public List<string> Client_List = new List<string>();
        public Hangman Hangman_Game;
        public bool Hangman_Playing = false;

        public Server(string IP, int PORT)
        {
            //Create IP Address - For Network Identification - So we can reference IP to send/recieve data
            IPAddress IP_Address = IPAddress.Parse(IP);

            //We create a TCPlistiner object , calling IP and Port (We get these from server main function , that calls this Server Function)
            TCP_Listener = new TcpListener(IP_Address, PORT);
        }

        /// <summary>
        /// Establishes server.
        /// 
        /// Listens to incomming connection requests (TCP_Listiner), when connection attempt is made by client (done in connect form , 
        /// invokes connect function in client, passing correct IP&Port to TCP_Client used to find then attempt connection to server).  
        /// 
        /// Each client connect request to server , the while loop is invoked, within this is the function "ClientConnect" , this function connects 
        /// our new client instance.
        /// 
        /// This works by the use of the while loop , since the while loop is set to true for-ever , this means the statement within will execute forever.
        /// So as a new client instance is made, compiler will see this loop then invoke statement within , giving us a ClientConnection logic to work correctly.
        /// 
        /// </summary>
        public void Start()
        {
            //Used for the server to listen for incomming connection requests - We will be listening to connect client requests
            TCP_Listener.Start();
            Console.WriteLine("Server : Starting");

            //Instantiates Concurrent Dictionary
            Clients = new ConcurrentDictionary<int, ConnectedClient>();
            

            while (true)
            {
                ClientConnect();
            }
         }
        
        public void ClientConnect()
        {
            //New Socket - Used to accept a connection request , allowing for sending/reciving of data.
            Socket socket = TCP_Listener.AcceptSocket();

            //Instantiate 
            Connected_Client = new ConnectedClient(socket);

            //Increment Dictionary Key
          
            Connected_Client.Client_Index_Key = ClientKeyIndex;
            //Adds new client instance to Dictionary , Key is accessser , value is a connected client 
            //Adds element on dictionary , passing incremented keyvalue & initialised connected client
            Clients.TryAdd(ClientKeyIndex, Connected_Client);
           

            Console.WriteLine("Server : Connection Made");

            //Passing ClientIndexkey allows for each instance of a connected client when they send data for the correct client instance to be regonised/
            Thread mainthread = new Thread(() => { ProcessClientResponse(Connected_Client.Client_Index_Key); });
            mainthread.Start();
            if (mainthread.IsAlive)
            {
                string clientcon = " is connected";
                Console.WriteLine("Client " + ClientKeyIndex + clientcon);

            }
            ClientKeyIndex++;
        }

        //Gets reference to each connect client, sends the packets when called to all connect clients besides the current client instance.
        public void SendPacket(ConnectedClient current_client , Packet packet)
        {

            foreach (ConnectedClient client in Clients.Values)
            {
                //If the local client instance is not equal to the client passed in , this will be true , so we pass a send packet to all clients that is not the current client 
                if (client != current_client)
                {
                    client.SendEncrypted(packet);
                }

            }

        }
     
        public void SendPacketAll(Packet packet)
        {
            foreach (ConnectedClient client in Clients.Values)
            {             
                    client.SendEncrypted(packet);
            }
        }
        //If invoked halts all connection attempts
        public void Stop()
        {
            TCP_Listener.Stop();
        }

        //Handles data sent into server, this will process what packet type the data was, then respond accordingly, the read/write handled in connect client instance , works similar to the method in client
       
        /// <summary>
        /// Handles Data Sent to server from client.
        /// Processes what packet type data sent is.
        /// Responds accordingly from packet type regonised
        /// send data back to the client.
        /// </summary>
        /// 
        private void ProcessClientResponse(int index)
        {
            //Gets current client instance (Client data was sent from)
            ConnectedClient current_client = Clients[index];
 
            Packet recieved_packet;

           while((recieved_packet = current_client.Read()) != null)
           {
                switch(recieved_packet.GetPacketType)
                {
                    /// <summary>
                    /// Establishes new client instance , passing its public key for the ability of the server to correctly instantiate public-key encryption with client.
                    /// </summary>
                    case PacketType.CONNECT:
                        ConnectPacket connectionpacket = (ConnectPacket)recieved_packet;
 
                        current_client.SetClientKey(connectionpacket.Public_Key);
                        current_client.Client_Name = connectionpacket.Client_Name;
                      
                        Client_List.Add(current_client.Client_Name);
                        UpdateClientList(current_client, Client_List);
                        current_client.SendPacket(new ClientKeyPacket(current_client.Public_Key));
                        break;

                    /// <summary>
                    /// Connect_Form sends two packets (Connect & ClientName Packet) - This packet is used for storing the newly connected clients name onto our servers client list.
                    /// To then update our clients client lists by sending the updated list to present all clients online. 
                    /// Further used to PM people and identify a client without needing to sending another packet since we the client_name is bound to the client instance (from connect packet)
                    /// </summary>
                    case PacketType.CLIENT_NAME:
                        ClientNamePacket clientnamepacket = (ClientNamePacket)recieved_packet;
                        string new_name = clientnamepacket.Client_Name;
                        string current_username = current_client.Client_Name;
                       
                            if (current_client.Client_Name != new_name)
                            {
                                Client_List.Remove(current_client.Client_Name);
                                current_client.Client_Name = new_name;
                                Client_List.Add(new_name);
                                UpdateClientList(current_client, Client_List);
                            }
                        break;

                    /// <summary>
                    /// Disconnects client from server , removing it from the client dictionary and client list, removing the total instance of that client being connected.
                    /// Update ClientList to indicate users of a client that left
                    /// </summary>
                    case PacketType.DISCONNECT:
                        DisconnectPacket disconnectpacket = (DisconnectPacket)recieved_packet;
                        foreach (ConnectedClient client in Clients.Values)
                        {
                            if(client.Client_Name == disconnectpacket.Client_Name)
                            {
                                Clients.TryRemove(client.Client_Index_Key , out current_client);
                                Client_List.Remove(client.Client_Name);
                              
                                client.Client_Name = null;
                                UpdateClientList(client , Client_List);
                            }
                        }

                        break;

                    /// <summary>
                    /// Sends Positional data to all other clients with the ID of the current client sending, the current clients index is used for the ID of client in game
                    /// </summary>
                    case PacketType.PLAYER_POSITION:
                        PlayerPositionPacket playerpositionpacket = (PlayerPositionPacket)recieved_packet;
                        playerpositionpacket.ID = Connected_Client.Game_ID;

                        //Sends Pos data too all other clients , updating position on other clients screens
                        foreach (ConnectedClient client in Clients.Values)
                        {
                            if (client != current_client)
                            {
                                client.SendPacket(new PlayerPositionPacket(playerpositionpacket.ID, playerpositionpacket.X, playerpositionpacket.Y));
                            }                             
                        }

                        break;

                    /// <summary>
                    /// Once Decrypted , holds instance to any packet type that was encrypted
                    /// All client related data via using the application is typically encrypted.
                    /// </summary>
                    case PacketType.ENCRYPTED:
                        
                        Packet decrypted = current_client.Decrypt((EncryptedPacket)recieved_packet);
                        
                        switch(decrypted.GetPacketType)
                        {
                            /// <summary>
                            /// Handles chat logic , and command logic if "/" is invoked in message sent
                            /// </summary>
                            case PacketType.CHAT_MESSAGE:
                                GlobalChatPacket chatmessagepacket = (GlobalChatPacket)decrypted;
                               
                                //If no command, send message as default
                                if(chatmessagepacket.Message.Contains("/"))
                                { ProcessCommand(current_client , chatmessagepacket.Message);}

                                else { SendPacket(current_client, chatmessagepacket);}

                                break;

                            /// <summary>
                            /// Once Decrypted , holds instance to any packet type that was encrypted
                            /// </summary>
                            case PacketType.PRIVATE_MESSAGE:
                                PrivateChatPacket private_chat_packet = (PrivateChatPacket)decrypted;
                                if (private_chat_packet.Sender == private_chat_packet.Recipient)
                                {
                                    current_client.SendEncrypted(new ErrorPacket("Error : You cannot PM yourself."));
                                }
                                else
                                {
                                      //Checks each client inside client dictionary , to find matchup
                                      foreach (ConnectedClient client in Clients.Values)
                                      {
                                          //Matchup of the username and recipient is a must , locating the correct client instance with the recipient allows us to find the client instance we send it too
                                          if (client.Client_Name == private_chat_packet.Recipient)
                                          {
                                          client.SendEncrypted(new PrivateChatPacket(private_chat_packet.Sender, private_chat_packet.Recipient, private_chat_packet.Message));
                                          }
                                      }
                                }
                                break;

                            /// <summary>
                            /// Handles message guess logic
                            /// </summary>
                            case PacketType.HANGMAN_GUESS:
                                HangmanGuessPacket hangmanguesspacket = (HangmanGuessPacket)decrypted;
                                string message;
                                //Hangman works with one letter guess each turn , rules imply to send guess as "/Guess 'char / 7th string element') 
                                //Easy work around to read guess inputs
                                Hangman_Game.UpdatedHangmanGame(hangmanguesspacket.Guess[7]);
                                if (Hangman_Playing == false)
                                {
                                    message = "Congratulations : Game won.";
                                    GlobalChatPacket globalchatpacket = new GlobalChatPacket("[Server]", message);
                                   SendPacketAll( globalchatpacket);
                                   Hangman_Playing = false;
                                }
                                else if (Hangman_Game.H_Lives == 0)
                                {
                                  message = "Unfortunate : Game Lost.";
                                  GlobalChatPacket globalchatpacket = new GlobalChatPacket("[Server]", message);
                                  SendPacketAll (globalchatpacket);
                                 Hangman_Playing = false;
                                }
                                break;
                            
                            /// <summary>
                            /// Handles logic of initialising our graphical solution
                            /// </summary>
                            case PacketType.GRAPHIC_INITIALISE:
                                GraphicInitialisePacket graphicinitialsepacket = (GraphicInitialisePacket)decrypted;

                                //Assing Game_ID
                                Connected_Client.Game_ID = Connected_Client.Client_Index_Key;
                                graphicinitialsepacket.ID = Connected_Client.Game_ID;
                                Game_ID_List.Add(Connected_Client.Game_ID);
                                
                                //Invoke sending List to add/update new clients connected to graphical solution 
                                //Further processing handled in clients
                                foreach (ConnectedClient client in Clients.Values)
                                {
                                        client.SendEncrypted(new GraphicInitialisePacket(Game_ID_List));
                                }
                                break;
                            case PacketType.GRAPHIC_EXIT:
                                GraphicExit graphicexit = (GraphicExit)decrypted;
                                graphicexit.ID = Connected_Client.Game_ID;
                                SendPacketAll( graphicexit);
                                 break;
                        }
                        break;
                }
           }
        }

   
        /// <summary>
        /// Logic from globalchatpacket
        /// processes message data invoked from "/"
        /// Logic handled in switch
        /// </summary>
        public void ProcessCommand(ConnectedClient current_client,string message)
        {
            switch(message)
            {
                //Initialises hangman if string data of message equals case
                case "/Play Hangman":
                    if (Hangman_Playing == true)
                    {
                        message = "Hangman match in session.";
                        PrivateChatPacket privatechatpacket = new PrivateChatPacket("[Server]", current_client.Client_Name, message);
                        current_client.SendEncrypted(privatechatpacket);
                    }
                    else
                    {
                        HangmanStartPacket hangmanstart = new HangmanStartPacket(message);
                        Hangman_Game = new Hangman(this);
                        Hangman_Playing = true;
                    }
                    //Invoked if Game either won or lost , ending Hangman instance
                    if(Hangman_Playing == false)
                    {
                        Hangman_Game = null;
                    }

                  break;
                case "/Help":
                    char s = 'Y';
                    HelpPacket help_packet = new HelpPacket(s);
                    current_client.SendEncrypted(help_packet);
                    break;
                default:
                    message = "Unknown command";
                    PrivateChatPacket unknownchatpacket = new PrivateChatPacket("[Server]", current_client.Client_Name, message);
                    current_client.SendEncrypted(unknownchatpacket);
                    break;


            }
        }


        /// <summary>
        /// Upon creation of new client connection , this is invoked to update pool of connected clients to update list boxes to see current selection of online clients.
        /// </summary>
        public void UpdateClientList(ConnectedClient current_client, List<string> client_list)
        {
            foreach (ConnectedClient client in Clients.Values)
            {
                client.SendEncrypted(new ClientListPacket(client_list, ""));
            }
        }
     
    }
}
