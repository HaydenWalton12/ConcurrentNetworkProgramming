﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerProj_
{
    class Program
    {
 
        static void Main(string[] args)
        {
            //Creates new server , calling the IP and the port 
            //Port is needed so our network knows where to send data too , IP is needed to use as address to send data.
            Server server = new Server("127.0.0.1", 4444);
            
            //Start function - Establishes TCP Connection and other functions
            server.Start();

            //Calls end to the server , closing functions
            server.Stop();

        }
    }
}
