﻿using System;
using System.Collections.Generic;
using System.Linq;
using Packets;

namespace ServerProj_
{

    /// <summary>
    /// Adaptation from week 1s hangman application
    /// </summary>
    class Hangman
    {

        Server H_Server;
        public int H_Lives;
        public int H_Score;
        public List<char> H_IncorrectLetters;
        public List<char> H_CorrectLetters;
        public string H_output_word;


        public string[] H_Words = { "ball" , "chicken" , "lead" , "leed" , "coat" };
     
        public  string H_Word;


        public Hangman(Server server)
        {
            H_Server = server;
            
            H_Lives = 6;
            H_Score = 0;
            
            H_IncorrectLetters = new List<char>();
            H_CorrectLetters = new List<char>();          
          
            Get_Word();
            GlobalChatPacket ruleschatpacket = new GlobalChatPacket("[Server]" , HangmanInformation());
            H_Server.SendPacketAll(ruleschatpacket);
        }

        //Assigns Game Word Randomly
        public void Get_Word()
        {
            //Used to assign us a random number to "ID" , we pass ID in String Array pa-rameter , giving us random word upon every execution.
            Random rand = new Random();
            var ID = rand.Next(0, 5);

            //Assigns Game Word
            H_Word = H_Words[ID];
        }



        /// <summary>
        /// Handles guess logic 
        /// </summary>
        public string Guess(char guess)
        {
            string message;
            //Check if word was correct  , if false , guess incorrect
            if (H_CorrectLetters.Contains(guess) || H_IncorrectLetters.Contains(guess))
            {
                message = guess.ToString() + " : has already been guessed";
                return message;

            }
            if (H_Word.Contains(guess))
            {
               
                H_CorrectLetters.Add(guess);
                message = guess.ToString() + " : was correct letter.";
                return message;
            }
            else
            {
                H_IncorrectLetters.Add(guess);
                message = guess.ToString() + " : was incorrect letter.";
                H_Lives--;
                return message;
            }
       
        
        }
        public string Update_Outputword()
        {
            string H_Output_Word = "";

            H_Server.Hangman_Playing = false;
            for (int i = 0; i < H_Word.Length; i++)
            {
           

                if (H_CorrectLetters.Contains(H_Word[i]))
                {
                    H_Output_Word += H_Word[i];
                }
                else
                {
                    H_Output_Word += "*";
                    H_Server.Hangman_Playing = true;
                }
            

            }
            return H_Output_Word;
        }

    
        /// <summary>
        /// Draws Hangman - 
        /// </summary>
        public string HangmanShow()
        {
            string Correct_Letters = "";
            string Incorrect_Letters = "";
            for (int i = 0; i < H_CorrectLetters.Count; i++)
            {
                Correct_Letters += H_CorrectLetters[i] + ",";

            }
            for (int i = 0; i < H_IncorrectLetters.Count; i++)
            {
                Incorrect_Letters += H_IncorrectLetters[i] + ",";

            }
            H_output_word = Update_Outputword();

            string hangman_state =
            "\n         ╔══════╗  " +
            "\n         ║      |  " +
            "\n         ║      " + (H_Lives < 6 ? "O" : "") +
            "\n         ║     " + (H_Lives < 4 ? "/" : "") + (H_Lives < 5 ? "|" : "") + (H_Lives < 3 ? @"\" : "") +
            "\n         ║     " + (H_Lives < 2 ? "/" : "") + " " + (H_Lives < 1 ? @"\" : "") +
            "\n         ║         " +
            "\n╔════╩══════╗" +
            "\n╚═══════════╝" +
            "\nCurrent word :" + H_output_word +
            "\nLives Remaining   : " + H_Lives +
            "\nIncorrect Letters : " + Incorrect_Letters +
            "\nCorrect Letters   : " + Correct_Letters;
                 ;
     
            return hangman_state;
        }

        /// <summary>
        ///Updates Game  , processes guess and updates hangman state 
        /// </summary>

        public void UpdatedHangmanGame(char guess)
        {
  
            //Send server guess response
            GlobalChatPacket guesspacket = new GlobalChatPacket("[Server]", Guess(guess));
            H_Server.SendPacketAll(guesspacket);
            //Show Initial Game Stage
            HangmanInstancePacket hangmaninstancepacketintial = new HangmanInstancePacket(HangmanShow());
            H_Server.SendPacketAll( hangmaninstancepacketintial);
        }
     
        /// <summary>
        /// Prints Rules
        /// </summary>
        public string HangmanInformation()
        {
            string rules =
            "\nRules are as followed:" +
            "\nGuess the word marked with '*', indicating length." +
            "\nBecareful however, you have only 6 guesses to share." +
            "\nOnly type one character per guess 'E.G /Guess a'." +
            "\nTo guess use command /Guess 'single character.'"+
            "\nAll characters must be lowercase!" + 
            "\nGoodluck!"+
            "\n\nStart with first /Guess.";
            return rules;
        }
    }

}
