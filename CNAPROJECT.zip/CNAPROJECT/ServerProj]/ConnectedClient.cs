﻿using Packets;
using System.IO;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;

namespace ServerProj_
{
    /// <summary>
    /// Server has to handle multiple client instances.
    /// ConnectedClient class allows server to handle each client independantly. Reading and writing to each client when nessecary
    /// 
    /// Servers TCPListiner will listen for incomming connections , when done so and we store that client instance , the server uses this for reason above.
    /// In result to this , this class will need all network components parallel to the client.Containing all the same network elements as our client.
    /// 
    /// Each client utilises a single thread (so server can read/write data indepedantly) ,  client instances stored on ConcurrentDictionary as an element, so each client is thread-safe.
    /// 
    /// 
    /// </summary>
    class ConnectedClient
    {


        //Network Components
       

        private NetworkStream Network_Stream;
        private BinaryReader Binary_Reader;
        private BinaryWriter Binary_Writer;
        private BinaryFormatter Binary_Formatter;



        private RSACryptoServiceProvider RSA_Provider;
        private RSAParameters Private_Key;
        public  RSAParameters Public_Key;
        private RSAParameters Client_Key;

        public int Game_ID;

        public int Client_Index_Key;
        //Stores 
        public string Client_Name;
        //Intantiates Network Components - Same method within client
        public ConnectedClient(Socket socket)
        {
            Network_Stream = new NetworkStream(socket, true);
            Binary_Reader = new BinaryReader(Network_Stream, Encoding.UTF8);
            Binary_Writer = new BinaryWriter(Network_Stream, Encoding.UTF8);
            Binary_Formatter = new BinaryFormatter();
            RSA_Provider = new RSACryptoServiceProvider(2048);
            Public_Key = RSA_Provider.ExportParameters(false);
            Private_Key = RSA_Provider.ExportParameters(true);
        }     
        public void Close()
        {
            Network_Stream.Close();
            Binary_Reader.Close();
            Binary_Writer.Close();
       
        }


        /// <summary>
        ///Sends Packet to Server , encrypts it before sending
        /// </summary>
        public void SendEncrypted(Packet packet)
        {
            Packet.SendPacket(Encrypt(packet), Binary_Formatter, Binary_Writer);
        }
   
        /// <summary>
        ///Decrypts packet passed in
        /// </summary>
        public Packet Decrypt(EncryptedPacket packet)
        {
            return EncryptedPacket.Decrypt(packet, RSA_Provider, Binary_Formatter, Private_Key);
        }
   
        /// <summary>
        ///Encrypts packet passed in
        /// </summary>
        public EncryptedPacket Encrypt(Packet packet)
        {
            return EncryptedPacket.Encrypt(packet, RSA_Provider, Binary_Formatter, Client_Key);
        }

        /// <summary>
        /// Setter
        /// </summary>
        public void SetClientName(string client_name)
        {

            Client_Name = client_name;
        }

        /// <summary>
        /// Setter
        /// </summary>
        public void SetClientKey(RSAParameters client_key)
        {
            Client_Key = client_key;
        }

        /// <summary>
        /// Reference Packet Class to read and return packet
        /// </summary>
        public Packet Read()
        {
            return Packet.Read(Binary_Formatter, Binary_Reader);
        }

        /// <summary>
        /// Reference Packet Class to Send Packets 
        /// </summary>  
        public void SendPacket(Packet packet)
        {
            Packet.SendPacket(packet, Binary_Formatter, Binary_Writer);
        }
   
    }
}
