﻿
using Packets;
using System.Windows;


namespace CNA_PROJECT_ASSINGMENT
{
    /// <summary>
    /// Interaction logic for HelpForm.xaml
    /// </summary>
    public partial class HelpForm : Window
    {



        public HelpForm(ClientProj.Client client)
        {
            InitializeComponent();

 

        }

      
    }
}
