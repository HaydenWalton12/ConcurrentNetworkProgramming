﻿using System;
using System.ComponentModel;
using System.Windows;
using Packets;
using System.Windows.Controls;
using System.Windows.Input;

using System.Windows.Shapes;
using System.Windows.Media;
using System.Reflection;
using System.Collections.Generic;

namespace CNA_PROJECT_ASSINGMENT
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        //Form Objects
        private ClientProj.Client Client;
        private UsernameControl ClientName_Form;
        private ConnectSystem Connect_Form;

        //Graphic Solution Data
        public double X_Pos, Y_Pos;
        int Player_Speed = 4;
        bool GoUp, GoDown ,GoRight, GoLeft;
        public Rectangle rectangle;
        public int ID;

        //Used to send private encrypted messages
        public string Username_Selected;

        public bool GlobalMessageState;

        //Initial Decleration of Form
        public MainWindow(ClientProj.Client client)
        {
            //Used for loading XAML UI Conent and WPF integration
            InitializeComponent();
            GlobalMessageState = true;
            ReconnectButton.IsEnabled = false;
            GraphicCanvas.Focus();
            Client = client;
            ExitGameButton.IsEnabled = false;
            GraphicCanvas.Visibility = Visibility.Hidden;
    
        }

        public void UpdatePrivateMessages(string client_name, string message)
        {
            MainChatBox.Dispatcher.Invoke(() =>
            {
                if (message == "Error : You cannot PM yourself.")
                {
                    UpdateChatBoxAlternitive(message);
                }
                else
                { 
                    MainChatBox.Text += "PM " + client_name + " : " + Environment.NewLine;
                    MainChatBox.Text += message + Environment.NewLine;
                }

                GlobalMessageState = true;
                MainChatBox.ScrollToEnd();
            });
        }


        public void UpdateChatBox(string client_name, string message)
        {
            MainChatBox.Dispatcher.Invoke(() =>
            {
                if (GlobalMessageState == true)
                {
                    MainChatBox.Text += client_name + " : " + Environment.NewLine;
                    MainChatBox.Text += message + Environment.NewLine + Environment.NewLine;

                }

                MainChatBox.ScrollToEnd();
            });
        }

        public void UpdateChatBoxAlternitive(string message)
        {
            MainChatBox.Dispatcher.Invoke(() =>
            {
                MainChatBox.Text += message + Environment.NewLine;

            });
        }

        /// <summary>
        /// Handles Message Packet Distribution Logic
        /// </summary>
        private void SendMessageButton_Click(object sender, RoutedEventArgs e)
        {
            //Instantiates and sends GlobalChatPacket
            if (GlobalMessageState == true)
            {
  
                if (MessageTextBox.Text.Contains("/Guess"))
                {

                    string guess = MessageTextBox.Text;
                    HangmanGuessPacket hangmanguesspacket = new HangmanGuessPacket(guess);
                    Client.SendEncrypted(hangmanguesspacket);

                }
                else
                {
                    //Update ChatBox Locally
                    UpdateChatBox("You", MessageTextBox.Text);
                    GlobalChatPacket chat_packet = new GlobalChatPacket(Client.Client_Name, MessageTextBox.Text);
                    Client.SendEncrypted(chat_packet);
                }


            }
            //Instantiates and sends PrivateChatPacket
            else
            {   
                PrivateChatPacket private_chat_packet = new PrivateChatPacket(Client.Client_Name, Username_Selected, MessageTextBox.Text);
                Client.SendEncrypted(private_chat_packet);

                //Unselects username , allowing to send global messages by default
                ClientList.SelectedItem = null;
                ClientList.UnselectAll();
                GlobalMessageState = true;
            }
        }

        private void ChangeClientName(object sender, RoutedEventArgs e)
        {
            ClientName_Form = new CNA_PROJECT_ASSINGMENT.UsernameControl(Client);
            ClientName_Form.ShowDialog();
            ClientName_Form.Close();
            ClientNameShowLabel.Content = Client.Client_Name;
        }
        //Clears previous listbox instance - Done to refresh client list if someone has joined/left
        public void RefreshClientList()
        {
            ClientList.Dispatcher.Invoke(() =>
                {
                    ClientList.Items.Clear();
                });
        }
        public void UpdateClientList(string[] usernames)
        {
            ClientList.Dispatcher.Invoke(() =>
            {

                foreach (string username in usernames)
                {
                    ClientList.Items.Add(username);
                    ClientList.Items.SortDescriptions.Add(new SortDescription("", ListSortDirection.Ascending));

                }

            });
        }
        /// <summary>
        /// Handles Disconnection Logic
        /// </summary>
        private void Disconnect_Click(object sender, RoutedEventArgs e)
        {
            //Sends Disconnect Packet to remove servers instance of this client
            Client.Disconnect();

            //Invoke Clients Chatbox and send button to not allow messages to be sent or seen
            MainChatBox.Dispatcher.Invoke(() =>
            {
                RefreshClientList();
                ReconnectButton.IsEnabled = true;
                ChangeUsernameButton.IsEnabled = false;
                DisconnectButton.IsEnabled = false;
                SendMessageButton.IsEnabled = false;
                MainChatBox.IsEnabled = false;
                MessageTextBox.IsEnabled = false;
                PlayGameButton.IsEnabled = false;
                ExitGameButton.IsEnabled = false;
                MainChatBox.Text = "You can no longer send messages.";
            });
        }

        /// <summary>
        /// Once Clicked , creates new instance of ConnectForm (Passing in correct client instance)
        /// </summary>
        private void Reconnect_Click(object sender, RoutedEventArgs e)
        {
            Close();
            Connect_Form = new CNA_PROJECT_ASSINGMENT.ConnectSystem(Client);
            bool ProcessInput_Successful = false;
            Connect_Form.ShowDialog();
            while (Connect_Form.ProcessInput(ProcessInput_Successful) == false) ;
            Connect_Form.AttemptConnect();
        }

        /// <summary>
        /// Used to determine who to send a private message too, once invoked, must send private message
        /// </summary>
        private void ClientList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Username_Selected = (string)ClientList.SelectedItem;
            GlobalMessageState = false;
        }



        public void HangmanTextUpdate(string message)
        {
            MainChatBox.Dispatcher.Invoke(() =>
            {
                if (GlobalMessageState == true)
                {
                    MainChatBox.Text += message + Environment.NewLine + Environment.NewLine;
                }
                MainChatBox.ScrollToEnd();
            });

        }

   

 
        /// <summary>
        /// Join  game/graphic canvas logic
        /// </summary>
        private void PlayGame_Click(object sender, RoutedEventArgs e)
        {
            PlayGameButton.IsEnabled = false;
            ExitGameButton.IsEnabled = true;
            ReconnectButton.IsEnabled = true;
            ChangeUsernameButton.IsEnabled = false;
            DisconnectButton.IsEnabled = false;
            SendMessageButton.IsEnabled = false;
            MainChatBox.IsEnabled = false;
            MessageTextBox.IsEnabled = false;
            GraphicCanvas.Visibility = Visibility.Visible;
            GraphicCanvas.Focus();
            GraphicInitialisePacket gamepacket = new GraphicInitialisePacket(null);
            Client.SendEncrypted(gamepacket);
        
        }

        /// <summary>
        /// Exit game/graphic canvas logic
        /// </summary>
        private void ExitGame_Click(object sender, RoutedEventArgs e)
        {
            PlayGameButton.IsEnabled = true;
            GraphicCanvas.Visibility = Visibility.Hidden;
            ExitGameButton.IsEnabled = false;
            ReconnectButton.IsEnabled = false;
            ChangeUsernameButton.IsEnabled = true;
            DisconnectButton.IsEnabled = true;
            SendMessageButton.IsEnabled = true;
            MainChatBox.IsEnabled = true;
           
            MessageTextBox.IsEnabled = true;
            GraphicExit graphicexitpacket = new GraphicExit();
            Client.SendEncrypted(graphicexitpacket);
        
        }
        public void UpdateGameList(int[] list)
        {
            GraphicCanvas.Dispatcher.Invoke(() =>
            {
                for(int i = 0; i < list.Length; i++)
                { 
                  GraphicCanvas.Children.RemoveAt(i);
                }
         
            });
        }

        /// <summary>
        /// Generates new child to GraphicCanvas
        /// </summary>
        public void AddGameUser(int ID , string name)
        {
           // string player = 1 += ID.ToString();
            GraphicCanvas.Dispatcher.Invoke(() =>
            {
                //Add Clients Local Instance
                rectangle = new Rectangle
                {
                    Name = name,
                    Height = 50,
                    Width = 50,
                    Fill = Brushes.BurlyWood,
             
                };
                
                GraphicCanvas.Children.Insert(ID, rectangle);
               
            });
                 
        }

        /// <summary>
        /// Generates new child to GraphicCanvas
        /// </summary>
        public void RemoveGameUser(int ID)
        {
            // string player = 1 += ID.ToString();
            GraphicCanvas.Dispatcher.Invoke(() =>
            {
               

                GraphicCanvas.Children.RemoveAt(ID);

            });

        }

        /// <summary>
        /// Movement Logic Influenced and expanded from
        /// https://www.youtube.com/watch?v=kSoVL6MuL5o&t=760s
        /// Local update , sends pos packet to to update on other clients
        /// </summary>
        public bool MoveLeft(bool goleft)
        {
            if (goleft == true && Canvas.GetLeft(Player) > 0)
            {
                 Canvas.SetLeft(Player, Canvas.GetLeft(Player) - Player_Speed);
                 X_Pos = Canvas.GetLeft(Player);

            }
            PlayerPositionPacket pos = new PlayerPositionPacket(ID, X_Pos, Y_Pos);
            Client.SendPacket(pos);
            return goleft;
        }
        public bool MoveRight(bool goright )
        {
            if (goright == true && Canvas.GetLeft(Player) < 410 )
            {
                Canvas.SetLeft(Player, Canvas.GetLeft(Player) + Player_Speed);
                X_Pos = Canvas.GetLeft(Player);
            }

            PlayerPositionPacket pos = new PlayerPositionPacket( ID ,X_Pos, Y_Pos);
           Client.SendPacket(pos);

            return goright;
        }
        public bool MoveUp(bool goup)
        {
            if (goup == true && Canvas.GetTop(Player) > 0)
            {
                
                Canvas.SetTop(Player, Canvas.GetTop(Player) - Player_Speed);
                Y_Pos = Canvas.GetTop(Player);

            }
            PlayerPositionPacket pos = new PlayerPositionPacket(ID, X_Pos, Y_Pos);
            Client.SendPacket(pos);
            return goup;
        }
        public bool MoveDown(bool godown)
        {
            if (godown == true && Canvas.GetTop(Player) < 260)
            {
                Canvas.SetTop(Player, Canvas.GetTop(Player) + Player_Speed);
                Y_Pos = Canvas.GetTop(Player);
            }
            PlayerPositionPacket pos = new PlayerPositionPacket(ID, X_Pos, Y_Pos);
            Client.SendPacket(pos);
            return godown;
        }

        /// <summary>
        /// Handle key down logic -  Movement starts based on key invoked "W,A,S,D"
        /// </summary>
        private void GraphicCanvas_KeyDown(object sender, KeyEventArgs e)
        {
            var child = GraphicCanvas.Children[ID];

            //Move Up
            if (e.Key == Key.W)
            {
                MoveUp(GoUp = true);
            }

            //Move Down
            if (e.Key == Key.S)
            {
                MoveDown(GoDown = true);
            }

            //Move Left
            if (e.Key == Key.A)
            {
                MoveLeft(GoLeft = true);

            }

            //Move right
            if (e.Key == Key.D)
            {
                MoveRight(GoRight = true);
            }
        }
        /// <summary>
        /// Handle key up logic - Stops movement once key down invoked is false
        /// </summary>
        private void GraphicCanvas_KeyUP(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.W)
            {
                GoUp = false;
            }
            else if (e.Key == Key.S)
            {
                GoDown = false;
            }
            else if (e.Key == Key.A)
            {
                GoLeft = false;
            }
            else if (e.Key == Key.D)
            {
                GoRight = false;
            }
        }

       
        /// <summary>
        /// Handles logic of updating canvas child positon
        /// </summary>
        public void UpdateChildPosition(double x , double y , int id)
        {
            GraphicCanvas.Dispatcher.Invoke(() =>
            {
                var child = GraphicCanvas.Children[id];

                Canvas.SetLeft(child, x);
                Canvas.SetRight(child, x);
                Canvas.SetTop(child, y);
                Canvas.SetBottom(child, y);
            });

        }
    }
}

