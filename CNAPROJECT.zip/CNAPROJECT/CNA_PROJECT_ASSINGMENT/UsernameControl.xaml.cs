﻿
using Packets;
using System.Windows;


namespace CNA_PROJECT_ASSINGMENT
{
    /// <summary>
    /// Interaction logic for UsernameControl.xaml
    /// </summary>
    public partial class UsernameControl : Window
    {
        private ClientProj.Client Client;




        public UsernameControl(ClientProj.Client client)
        {
            InitializeComponent();

            Client = client;

        }

        //Data inputed into text box overwrites previous data in client
        private void SendMessageButton_Click(object sender, RoutedEventArgs e)
        {

            Client.Client_Name = UsernameTextBox.Text;
            ChangeUsername();
            Close();
        }


        public void ChangeUsername()
        {
            ClientNamePacket usernamepacket = new ClientNamePacket(Client.Client_Name);
            Packet.SendPacket(usernamepacket, Client.Binary_Formatter, Client.Binary_Writer);
        }
    }
}
