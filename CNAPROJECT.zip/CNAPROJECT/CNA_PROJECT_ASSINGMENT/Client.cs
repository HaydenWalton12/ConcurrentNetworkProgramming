﻿using System;
using System.Net.Sockets;
using System.IO;
using System.Text;
using System.Threading;
using Packets;
using System.Security.Cryptography;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;

namespace ClientProj
{
    /// <summary>
    ///  Client Class provides backend interface to how we send , recieve and process data for our WPF Chat Application.
    /// </summary>
    
    public class Client
    {
        /// <summary>
        /// Network Objects Providing gateway to send/recieve and manipulate data
        /// </summary>
       
        public TcpClient TCP_Client;                    //Provides Client Connectivity
        public Stream Network_Stream;                   //Provides I/O gateway to read/write from our network socket
        public BinaryWriter Binary_Writer;              //Allow us to write data to a stream
        public BinaryReader Binary_Reader;              //Allow us to read data from a stream
        public BinaryFormatter Binary_Formatter;        //Serializes/Deserlizes data from stream

        public List<int> Game_ID = new List<int>();

        private RSACryptoServiceProvider RSA_Provider;  //Provides RSA_Encryption Services

        /// <summary>
        /// Encryption Keys are used for permitting access to accessing encrypted data.
        /// Private Key should only be locally stored on the client , used for the permitted access to decrypt incomming data.
        /// 
        /// Public Key is used to encrypt data , reciever and sender 
        /// must  have this key matched (Server/Client Key store value of recipients public key - E.G Server_Key = Servers's Public_Key vice versa)
        ///
        /// Utilises Public-Key Encyrption method
        /// </summary>
       
        private RSAParameters Private_Key;
        public RSAParameters Public_Key;
        public RSAParameters  Server_Key;

        //WPF APPLICATION Objects - Used to reference form objects
        private CNA_PROJECT_ASSINGMENT.MainWindow Client_Form;
        private CNA_PROJECT_ASSINGMENT.ConnectSystem Connect_Form;
        private CNA_PROJECT_ASSINGMENT.HelpForm Help_Form;
        //Stores local copy of username
        public string Client_Name;

        //Manages and determines client connectivity to server , set to true in ConnectClient , if Disconnect Button is clicked we set it to false then send a singal to issue the disconnecr.
        public bool Client_Connected;

        //Class Constructor - Instantiates TCP CLient
        public Client()
        {
            //Instantiate Connect_Form
            Connect_Form = new CNA_PROJECT_ASSINGMENT.ConnectSystem(this);
            
            //Opens Connect Form
            Connect_Form.ShowDialog();
            
            //This will continously test until ProcessInput Returns bool as true
            bool ProcessInput_Successful = false;
            while (Connect_Form.ProcessInput(ProcessInput_Successful) == false)
            {
                Connect_Form.Close();
                Connect_Form.ShowDialog();
                Connect_Form.ProcessInput(ProcessInput_Successful);
            }
            Connect_Form.AttemptConnect();
  
        }
        public void Close()
        {
            Binary_Writer.Close();
            Binary_Reader.Close();
            Network_Stream.Close();
            TCP_Client.Close();
        }


        /// <summary>
        ///Referenced in Connect_Form - Connection Attempt made
        /// </summary>
        public bool ConnectClient(string ip , int port)
        {
            try
            {
                //Instantiate & attempt TCP Connection
                TCP_Client = new TcpClient();
                TCP_Client.Connect(ip, port);
           
                //Instantiate RSA Cryptography Components
                RSA_Provider = new RSACryptoServiceProvider(2048);
                Public_Key = RSA_Provider.ExportParameters(false);
                Private_Key = RSA_Provider.ExportParameters(true);

                //Return Network Stream From Client , allowing us to utilise stream for data transmission
                Network_Stream = TCP_Client.GetStream();

                //Intantiate Network Components, for reading , writing and serializing data
                Binary_Reader = new BinaryReader(Network_Stream, Encoding.UTF8);
                Binary_Writer = new BinaryWriter(Network_Stream, Encoding.UTF8);
                Binary_Formatter = new BinaryFormatter();
               
                Connect_Form.Close();

                Client_Connected = true;
          
                return true;
            }

            //Error Check - If Client Unsuccessfully Connects
            catch (Exception e)
            {
                Console.WriteLine("Exception : " + e.Message);
                return false;
            }
        }

        /// <summary>
        ///Handles client Execution
        /// </summary>
        public void Run()
        {
            //Instantiate Main Form to current client instance "this" 
            Client_Form = new CNA_PROJECT_ASSINGMENT.MainWindow(this);

            //Instantiate and run main client thread
            Thread mainthread = new Thread(() => { ProcessServerRespond(); });
            mainthread.SetApartmentState(ApartmentState.STA);
            mainthread.Start();

            Client_Form.ClientNameShowLabel.Content = Client_Name;

            //Opens Client Form
            Client_Form.ShowDialog();
        }

        /// <summary>
        /// Data (Form as Packets) sent from server to client, gets processed here.
        /// </summary>
        private void ProcessServerRespond()
        {
            //Continuous Loop - Will read packets while connected
            while (Client_Connected)
            {
                //Packet used to read data into
                Packet packet;
                
                //Checks to see if data receieved has anydata
                if ((packet = Packet.Read(Binary_Formatter , Binary_Reader)) != null)
                {

                    /// <summary>
                    /// Gets Packet Type from processed packet , allows for correct processing based on type.
                    /// </summary> 
                    switch (packet.GetPacketType)
                    {

                        /// <summary>
                        /// Enables Public Key Encyrption
                        /// </summary>           
                        case PacketType.CLIENT_KEY:
                            ClientKeyPacket clientKeypacket = (ClientKeyPacket)packet;
                            Server_Key = clientKeypacket.Public_Key;
                            break;


                        /// <summary>
                        /// Handles client side updating ID referenced player instance
                        /// </summary> 
                        case PacketType.PLAYER_POSITION:
                            PlayerPositionPacket pos = (PlayerPositionPacket)packet;
                            Client_Form.UpdateChildPosition(pos.X, pos.Y, pos.ID);
                            break;

                        /// <summary>
                        /// All Client data is by default encrypted , requires further processing 
                        /// , decrypting the encrypted data packet to revial what the packet type encrypted was
                        /// </summary>             
                        case PacketType.ENCRYPTED:

                            //Local Packet type , decrypts packet
                            Packet decrypted = EncryptedPacket.Decrypt((EncryptedPacket)packet , RSA_Provider , Binary_Formatter , Private_Key);

                            /// <summary>
                            ///Decrypting packet allows previously encrypted packet to be fully presented , use of switch to get packet type for correcting packet processing
                            ///Within each case, to access packet data , new local packet is created with the packet type , assigning the new packet made to equal decrypted packet
                            ///This is done so we can correctly access the data within the packet type
                            /// </summary>    

                            switch (decrypted.GetPacketType)
                            {
                                /// <summary>
                                /// Pass packet data to update chatbox
                                /// </summary>  
                                case PacketType.CHAT_MESSAGE:
                                    GlobalChatPacket chat_packet = (GlobalChatPacket)decrypted;
                                    Client_Form.UpdateChatBox(chat_packet.Client_Name, chat_packet.Message);
                                    break;


                                /// <summary>
                                /// Update chatbox , pass packet data from server
                                /// </summary>  
                                case PacketType.PRIVATE_MESSAGE:
                                    PrivateChatPacket private_chat_packet = (PrivateChatPacket)decrypted;
                                    Client_Form.UpdatePrivateMessages(private_chat_packet.Sender , private_chat_packet.Message);
                                        break;

                                /// <summary>
                                /// Handles Error Message logic
                                /// </summary>  
                                case PacketType.ERRORMESSAGE:
                                    ErrorPacket errorpacket = (ErrorPacket)decrypted;
                                    Client_Form.UpdateChatBoxAlternitive(errorpacket.Error_Message);
                                    break;
                                
                                /// <summary>
                                /// Clear previous instance of ListBox
                                /// Store username_list into array
                                /// Array passed into ListBox update function
                                /// </summary>                           
                                case PacketType.CLIENT_LIST:                      
                                    Client_Form.RefreshClientList();                                          
                                    ClientListPacket ClientListpacket = (ClientListPacket)decrypted;                                                              
                                    string[] client_list = ClientListpacket.Client_List.ToArray();                                                                                                   
                                    Client_Form.UpdateClientList(client_list);
                                    break;

                                /// <summary>
                                /// Intantiates Hangman Game , showing initial hangman state and rules of use

                                /// </summary>           
                                case PacketType.HANGMAN_INSTANCE:
                                    HangmanInstancePacket hangmaninstancepacket = (HangmanInstancePacket)decrypted;
                                    Client_Form.HangmanTextUpdate(hangmaninstancepacket.Instance);
                                    break;

                                /// <summary>
                                /// Passed Game_ID List, Renders all networked/connect clients to graphical solution
                                /// Has current issues with correct syncing and storing of children in canvas to the correct canvas count
                                /// When client count is above 3 , issues start to occur
                                /// </summary> 
                                case PacketType.GRAPHIC_INITIALISE:
                                    GraphicInitialisePacket graphicalinitialisepacket = (GraphicInitialisePacket)decrypted;
                                    Client_Form.ID = graphicalinitialisepacket.ID;
                                    Game_ID.Add(Client_Form.ID);
                                    
                                    int[] game_list = graphicalinitialisepacket.ID_List.ToArray();
                                              
                                    foreach(int i in game_list)
                                    {
                                        if (game_list[i] != Client_Form.ID)
                                        {
                                         
                                            Client_Form.AddGameUser(game_list[i], Client_Name);
                                        }
                                       
                                    }                   
                                    
                                    break;

                                case PacketType.GRAPHIC_EXIT:
                                    GraphicExit graphicexit = (GraphicExit)decrypted;

                                    foreach(int i in Game_ID)
                                    {
                                        if (i == graphicexit.ID)
                                        {
                                            Client_Form.RemoveGameUser(i);   
                                        }
                                    }
                                    break;
                                /// <summary>
                                /// Handles logic for opening help form if command was invoked on server
                                /// </summary> 
                                case PacketType.HELP:
                                    Help_Form = new CNA_PROJECT_ASSINGMENT.HelpForm(this);
                                    Help_Form.ShowDialog();
                                    break;
                            }
                            break;
                    }
                }
            }
        }

        /// <summary>
        /// Disconnects Client from server
        /// </summary>
        public void Disconnect()
        {
            Client_Connected = false;
            DisconnectPacket disconnectpacket = new DisconnectPacket(Client_Name);
            SendPacket(disconnectpacket);
        }
      
        //Sends Packet to Server , encrypts it before sending
        public void SendEncrypted(Packet packet)
        {
            Packet.SendPacket(Encrypt(packet), Binary_Formatter, Binary_Writer);
        }
        //Decrypts packet passed in
        public Packet Decrypt(EncryptedPacket packet)
        {
            return EncryptedPacket.Decrypt(packet, RSA_Provider, Binary_Formatter, Private_Key);
        }

        //Encrypts packet passed in
        public EncryptedPacket Encrypt(Packet packet)
        {
            return EncryptedPacket.Encrypt(packet, RSA_Provider, Binary_Formatter, Server_Key);
        }

        //Reference Packet Class to read and return packet
        public Packet Read()
        {
            return Packet.Read(Binary_Formatter, Binary_Reader);
        }

        //Reference Packet Class to Send Packets 
        public void SendPacket(Packet packet)
        {
            Packet.SendPacket(packet, Binary_Formatter, Binary_Writer);
        }      
    }
}