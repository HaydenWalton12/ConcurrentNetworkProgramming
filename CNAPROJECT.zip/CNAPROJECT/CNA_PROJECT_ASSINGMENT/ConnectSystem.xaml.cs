﻿using Packets;
using System;
using System.Windows;



namespace CNA_PROJECT_ASSINGMENT
{
    /// <summary>
    /// Interaction logic for ConnectSystem.xaml
    /// </summary>
    /// 

    public partial class ConnectSystem : Window
    {
        const string IP = "127.0.0.1";
        const int port = 4444;
        private ClientProj.Client Client;

        public ConnectSystem(ClientProj.Client client)
        {
            InitializeComponent();
            Client = client;
            IPShowLabel.Content = IP;
            PortShowLabel.Content = port;
     
        }
        private void SendMessageButton_Click(object sender, RoutedEventArgs e)
        {

           bool flag = false;

            //If returned false we get error message
            if (ProcessInput(flag) == false)
            {
                ErrorMessage();
            }
          
        }

        //Takes inpuuted values from form , processes them to see if they equate to anything,  if not then returns as false and we have to try again
        public bool ProcessInput(bool flag)
        {
          
            if (UsernameTextBox.Text == "")
            {
                MessageBox.Show("Please enter Username Entry");
                return flag = false;
            }
            else
            {

                //Local Client value equates to entered value
                Client.Client_Name = UsernameTextBox.Text;
              
            }
            Close();

            return flag = true;
        }

        //Will attempt to establish connection to Host TCP Listiner (our server)
        public  void AttemptConnect()
        {
           if(Client.ConnectClient(IP , port))
            {
                ConnectPacket connect_packet = new ConnectPacket(Client.Public_Key , Client.Client_Name);
                Client.SendPacket(connect_packet);
                Client.Run();
            }
            else
            {
                Console.WriteLine("Client failed to connect to server. ");
                MessageBox.Show("Failed to connect to server.");
            }

        }
        //Exatctly as name implies
        public void ErrorMessage()
        {
            MessageBox.Show("Could not connect to server ...");
        }
            
    
    }
}
