﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;

namespace Packets
{
    public enum PacketType
    {
        LOGIN,
        CONNECT,
        CLIENT_KEY,
        CLIENT_NAME,
        CLIENT_LIST,
        ENCRYPTED,
        RECONNECT,
        DISCONNECT,
        CHAT_MESSAGE,
        PRIVATE_MESSAGE,
        ERRORMESSAGE,
        HANGMAN_START,
        HANGMAN_INSTANCE,
        HANGMAN_GUESS,
        GRAPHIC_INITIALISE,
        GRAPHIC_EXIT,
        GRAPHIC_LIST,
        PLAYER_POSITION,
        HELP,
    }

    [Serializable()]
    public abstract class Packet
    {

        public PacketType GetPacketType
        {
            get; protected set;
        }

        /// <summary>
        /// 
        /// Packet send method provided in tutorials , enacts as authoritive
        /// method of processing packets between server and client
        /// </summary>
        public static void SendPacket(Packet packet, BinaryFormatter binary_formatter, BinaryWriter binary_writer)
        {
            //Prevents Race-Conditions
            object Write_Lock = new Object();

            MemoryStream stream = new MemoryStream();

            lock (Write_Lock)
            {
                binary_formatter.Serialize(stream, packet);
                byte[] buffer = stream.GetBuffer();
                binary_writer.Write(buffer.Length);
                binary_writer.Write(buffer);
                binary_writer.Flush();
            }
        }
        /// <summary>
        /// Reads incomming packet data 
        /// 
        /// </summary>

        public static Packet Read(BinaryFormatter binary_formatter, BinaryReader binary_reader)
        {
            //Prevents Race-Conditions
            object Read_Lock = new object();

            lock (Read_Lock)
            {

                //Will be used to store the size of number of bytes , to which it will be passed into reader to determine how many bytes the reader reads (this is done we read the correct amount of current data in stream)
                int numberofbytes;
                if ((numberofbytes = binary_reader.ReadInt32()) != -1)
                {

                    //Buffer Created , stores the readers data , amount determined by numberofbytes
                    byte[] buffer = binary_reader.ReadBytes(numberofbytes);

                    //Memory Stream created , holds buffer data that it got from reader
                    MemoryStream readstream = new MemoryStream(buffer);

                    // Returns Bytes from stream as packet 
                    return binary_formatter.Deserialize(readstream) as Packet;
                }

                //Return null if nothing was read
                return null;
            }
        }
    }
    /// <summary>
    /// 
    /// </summary>
    [Serializable()]
    public class EncryptedPacket : Packet
    {
        byte[] Data;
        public EncryptedPacket(byte[] data)
        {
            Data = data;
            GetPacketType = PacketType.ENCRYPTED;
        }

        //Prevent Race Condition
        public static object Encrypt_Lock = new object();
        public static object Decrypt_Lock = new object();

        /// <summary>
        /// Authorative method for encrypting any packet of choice.
        /// 
        /// Anything higher than 128 Bytes, would create a "bad length" since RSA encryption handles data in small chunks. 1024(size of data passed) / 8 = 128 (bytes). 
        /// Input has to be 128 bytes since we can only output 256 bytes at a time (due to our keysize , check bookmarks for further reason) our data after encryption essentially doubles , making our data same size as 
        /// encryption key (highest size)
        /// 
        /// 
        /// </summary>
        public static EncryptedPacket Encrypt(Packet packet, RSACryptoServiceProvider rsa_provider, BinaryFormatter binary_formatter, RSAParameters public_key)
        {


            //Input is 128 bytes (highest amount per chunk) , ouput is 256 when encrypted (reason in summary)
            const int ByteChunk = 128;
            const int EncryptedByteChunk = 256;

            //Both used to correctly index the accessing and storing of the data being processed in "chunks / segments" , 
            int chunk_instance = 0;
            int encrypted_chunk_instance = 0;

            //Loads data 
            MemoryStream memory = new MemoryStream(1024);

            //Stores all encrypted data 
            byte[] Encrypted_Data = new byte[2048];
            binary_formatter.Serialize(memory, packet);
            byte[] buffer = memory.GetBuffer();

            //Each iteration loads , encrypts and stores each chunk
            while (chunk_instance != buffer.Length)
            {
                //Stores each chunk 
                byte[] Data_Segment = new byte[ByteChunk];

                //Read Data into current segment 
                for (int current_byte = 0; current_byte < ByteChunk; current_byte++)
                {
                    Data_Segment[current_byte] = buffer[chunk_instance + current_byte];
                }

                //Allows us to correctly index next chunk of data encapsulated in for loop. E.G (byte_chunk_instance = 256 + 0 , + 1 , + 2"current_byte" = 256 , 257  , 258...)
                chunk_instance += Data_Segment.Length;


                byte[] temporary_encrypted_data;

                //Prevent race condition
                lock (Encrypt_Lock)
                {

                    //Import Key for use
                    rsa_provider.ImportParameters(public_key);
                    //Copy encrypted elements of the list into the local data (byte type) array.
                    temporary_encrypted_data = rsa_provider.Encrypt(Data_Segment, true);
                }

                //Load temp encrypted data into the main Encrypted data object that stores all chunks
                for (int current_byte = 0; current_byte < EncryptedByteChunk; current_byte++)
                {
                    //And add them to our output
                    Encrypted_Data[encrypted_chunk_instance + current_byte] = temporary_encrypted_data[current_byte];
                }

                //Allows to correctly index next chunk of data 
                encrypted_chunk_instance += temporary_encrypted_data.Length;
            }

            //Copy encrypted elements of the list into packet.
            EncryptedPacket encryptedpacket = new EncryptedPacket(Encrypted_Data);
            return encryptedpacket;
        }

        /// <summary>
        /// Logic works similar to decrypt
        /// 
        /// 256 Bytes Per while-loop iteration - Decrypts 256 bytes each time , if any higher. Errors would occur ("To be decrypted exceeds the maximum for this modulus of 256 bytes.") 
        /// Meaning we can only read 256 Bytes Each iteration.
        /// </summary>

        public static Packet Decrypt(EncryptedPacket packet, RSACryptoServiceProvider rsa_provider, BinaryFormatter binary_formatter, RSAParameters private_key)
        {
            //Explained in summary
            const int EncryptedByteBulk = 256;
            const int DecryptedByteBulk = 128;

            //Both used to correctly index the accessing and storing of the data being processed in "chunks / segments" , 
            int encrypted_byte_instance = 0;
            int decrypted_byte_instance = 0;

            //Stores all decrypt data
            byte[] Decrypted_Data = new byte[1024];


            //Decrypts data in chunks
            while (encrypted_byte_instance != packet.Data.Length)
            {
                //Stores each chunk 
                byte[] Data_Segment = new byte[EncryptedByteBulk];

                //Read Data into current segment 
                for (int current_byte = 0; current_byte < EncryptedByteBulk; current_byte++)
                {
                    Data_Segment[current_byte] = packet.Data[encrypted_byte_instance + current_byte];
                }

                //Allows to correctly index next chunk of data 
                encrypted_byte_instance += Data_Segment.Length;

                byte[] temporary_decrypted_data;

                //Decypts loaded chunk
                lock (Decrypt_Lock)
                {
                    rsa_provider.ImportParameters(private_key);
                    temporary_decrypted_data = rsa_provider.Decrypt(Data_Segment, true);
                }

                //Stores decrypted chunk into main location
                for (int current_byte = 0; current_byte < DecryptedByteBulk; current_byte++)
                {
                    //And add them to our output
                    Decrypted_Data[decrypted_byte_instance + current_byte] = temporary_decrypted_data[current_byte];
                }

                //Allows to correctly index next chunk of data 
                decrypted_byte_instance += temporary_decrypted_data.Length;
            }

            MemoryStream memoryStream = new MemoryStream(Decrypted_Data);

            Packet decryptedpacket = binary_formatter.Deserialize(memoryStream) as Packet;
            return decryptedpacket;
        }


    }

    /// <summary>
    /// Connects / Reconnects Clients 
    /// </summary>
    [Serializable()]
    public class ConnectPacket : Packet
    {
        public RSAParameters Public_Key;

        public string Client_Name;
        public ConnectPacket(RSAParameters public_key, string client_name)
        {
            Client_Name = client_name;
            Public_Key = public_key;
            GetPacketType = PacketType.CONNECT;

        }
    }

    /// <summary>
    /// Disconnects Clients from server
    /// </summary>
    [Serializable()]
    public class DisconnectPacket : Packet
    {
        public string Client_Name;

        public DisconnectPacket(string client_name)
        {
            Client_Name = client_name;
            GetPacketType = PacketType.DISCONNECT;
        }
    }

    /// <summary>
    /// Used within connecting client - server
    /// </summary>
    [Serializable()]
    public class ClientKeyPacket : Packet
    {
        public RSAParameters Public_Key;
        public ClientKeyPacket(RSAParameters public_Key)
        {
            Public_Key = public_Key;
            GetPacketType = PacketType.CLIENT_KEY;
        }
    }

    /// <summary>
    /// Proccesses global messages across all clients
    /// </summary>
    [Serializable()]
    public class GlobalChatPacket : Packet
    {
        public string Client_Name;
        public string Message;
        public GlobalChatPacket(string client_name, string message)
        {
            Client_Name = client_name;
            Message = message;
            GetPacketType = PacketType.CHAT_MESSAGE;
        }
    }


    /// <summary>
    /// Distributes recipient - sender messages
    /// </summary>
    [Serializable()]
    public class PrivateChatPacket : Packet
    {
        public string Sender;
        public string Recipient;
        public string Message { get; private set; }

        public PrivateChatPacket(string sender, string recipient, string message)
        {
            Sender = sender;
            Recipient = recipient;
            Message = message;
            GetPacketType = PacketType.PRIVATE_MESSAGE;

        }
    }

    /// <summary>
    /// Used to update client name
    /// </summary>
    [Serializable()]
    public class ClientNamePacket : Packet
    {

        public string Client_Name;

        public ClientNamePacket(string client_name)
        {
            Client_Name = client_name;
            GetPacketType = PacketType.CLIENT_NAME;

        }
    }

    /// <summary>
    /// Used to distribute error messages
    /// </summary>
    [Serializable()]
    public class ErrorPacket : Packet
    {
        public string Error_Message;

        public ErrorPacket(string error_message)
        {
            Error_Message = error_message;
            GetPacketType = PacketType.ERRORMESSAGE;
        }
    }

    /// <summary>
    /// Initialise Hangman Globally
    /// </summary>
    [Serializable()]
    public class HangmanStartPacket : Packet
    {
        public string Start_Hangman;

        public HangmanStartPacket(string start_hangman)
        {
            Start_Hangman = start_hangman;
            GetPacketType = PacketType.HANGMAN_START;
        }
    }

    /// <summary>
    /// Handles hangman instance
    /// </summary>
    [Serializable()]
    public class HangmanInstancePacket : Packet
    {
        public string Instance;

        public HangmanInstancePacket(string instance)
        {
            Instance = instance;
            GetPacketType = PacketType.HANGMAN_INSTANCE;
        }
    }

    /// <summary>
    /// Handles hangman guess logic
    /// </summary>
    [Serializable()]
    public class HangmanGuessPacket : Packet
    {
        public string Guess;

        public HangmanGuessPacket(string guess)
        {
            Guess = guess;
            GetPacketType = PacketType.HANGMAN_GUESS;
        }
    }

    /// <summary>
    /// Handles client list logic , updating primarily
    /// </summary>
    [Serializable()]
    public class ClientListPacket : Packet
    {
        public List<string> Client_List;
        public string Client_Name;

        public ClientListPacket(List<string> client_list, string client_name)
        {
            Client_List = client_list;
            GetPacketType = PacketType.CLIENT_LIST;
        }
    }

    /// <summary>
    /// Handle sync Logic , store client IDs 
    /// </summary>
    [Serializable()]
    public class GraphicInitialisePacket : Packet
    {
        public int ID;
        public List<int> ID_List;
        public GraphicInitialisePacket(List<int> id_list)
        {
            ID_List = id_list;
            GetPacketType = PacketType.GRAPHIC_INITIALISE;
        }
    }

    /// <summary>
    /// Handle sync Logic , store client IDs 
    /// </summary>
    [Serializable()]
    public class GraphicExit : Packet
    {
        public int ID;

        public GraphicExit()
        {
   
            GetPacketType = PacketType.GRAPHIC_EXIT;
        }
    }
    /// <summary>
    /// Handle user position logic for graphical simulation
    /// </summary>
    [Serializable()]
    public class PlayerPositionPacket : Packet
    {
        public double X;
        public double Y;
        public int ID;
        public PlayerPositionPacket(int id, double x, double y)
        {
            X = x;
            Y = y;
            ID = id;
            GetPacketType = PacketType.PLAYER_POSITION;
        }
    }

    [Serializable()]
    public class HelpPacket : Packet
    {
        public char Signal;
        public HelpPacket(char signal)
        {
            Signal = signal;
             GetPacketType = PacketType.HELP;
        }
    }
}
