﻿using System;
using System.IO;
using System.Runtime.Serialization;


namespace PacketSystem
{
    public enum PacketType
    {
        ChatMessage,
        PrivateMessage,
        ClientName,
    }
    [Serializable()]
    public abstract class Packet
    {

        public PacketType GetPacketType
        {
            get; protected set;

        }


    }

    [Serializable()]
    public class ChatMessagePacket : Packet
    {

        public string Message { get; private set; }

        public ChatMessagePacket(string message)
        {

            Message = message;


        }




    }



}
